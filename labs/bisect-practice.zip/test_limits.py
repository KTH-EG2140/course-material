from limits import limit_for

def test_known_levels():
    assert limit_for(400.0) == 2.0
    assert limit_for(135.0) == 0.9

def test_fallback():
    assert limit_for(300.0) == 0.5
