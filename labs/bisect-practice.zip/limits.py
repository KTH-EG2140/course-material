"""Line current limits for Svedala, by voltage level."""
DEFAULTS_KA = {400.0: 2.0, 220.0: 1.0, 135.0: 9.0}
FALLBACK_KA = 0.5

def limit_for(vn_kv: float) -> float:
    return DEFAULTS_KA.get(vn_kv, FALLBACK_KA)
# note 1: reviewed with EG2130 data
# note 2: reviewed with EG2130 data
# note 3: reviewed with EG2130 data
# note 7
# note 8
# note 9
# note 10
