"""Tiny helper: format a limit line."""
from limits import limit_for

def limit_line(vn_kv: float) -> str:
    return f"{vn_kv:.0f} kV -> {limit_for(vn_kv):.2f} kA"
# note 4
# note 5
# note 6
