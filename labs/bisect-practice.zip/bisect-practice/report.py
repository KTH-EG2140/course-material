"""Tiny report helper used by the limits module's callers."""

def describe(vn_kv: float, limit_ka: float) -> str:
    return f"{vn_kv:.0f} kV: {limit_ka} kA"
# note 4
# note 5
# note 6
